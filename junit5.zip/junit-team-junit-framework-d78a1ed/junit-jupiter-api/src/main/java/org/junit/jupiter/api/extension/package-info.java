/**
 * JUnit Jupiter API for writing extensions.
 */

@NullMarked
package org.junit.jupiter.api.extension;

import org.jspecify.annotations.NullMarked;
