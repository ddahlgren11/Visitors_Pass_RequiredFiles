/**
 * IO-related support in JUnit Jupiter.
 */

@NullMarked
package org.junit.jupiter.api.io;

import org.jspecify.annotations.NullMarked;
