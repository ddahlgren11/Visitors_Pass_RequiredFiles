/**
 * Annotation-based conditions for enabling or disabling tests in JUnit Jupiter.
 */

@NullMarked
package org.junit.jupiter.api.condition;

import org.jspecify.annotations.NullMarked;
