/**
 * JUnit Jupiter API support for writing extensions.
 */

@NullMarked
package org.junit.jupiter.api.extension.support;

import org.jspecify.annotations.NullMarked;
