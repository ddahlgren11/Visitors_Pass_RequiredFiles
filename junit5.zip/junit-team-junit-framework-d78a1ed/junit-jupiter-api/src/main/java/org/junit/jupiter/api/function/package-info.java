/**
 * Functional interfaces used within JUnit Jupiter.
 */

@NullMarked
package org.junit.jupiter.api.function;

import org.jspecify.annotations.NullMarked;
