/**
 * JUnit Jupiter API for influencing parallel test execution.
 */

@NullMarked
package org.junit.jupiter.api.parallel;

import org.jspecify.annotations.NullMarked;
