/**
 * JUnit Jupiter API for writing tests.
 */

@NullMarked
package org.junit.jupiter.api;

import org.jspecify.annotations.NullMarked;
