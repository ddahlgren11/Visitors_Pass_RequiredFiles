---
name: Create a task
about: Create a task for a specific piece of work
type: Task
labels: ["type: task"]
---

<!-- Please describe what needs to be done to consider this task completed. -->

## Deliverables

- [ ] ...
