
@NullMarked
package example.testinterface;

import org.jspecify.annotations.NullMarked;
