
@NullMarked
package example.defaultmethods;

import org.jspecify.annotations.NullMarked;
