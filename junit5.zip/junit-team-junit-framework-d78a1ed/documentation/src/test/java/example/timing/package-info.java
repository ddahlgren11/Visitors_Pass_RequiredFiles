
@NullMarked
package example.timing;

import org.jspecify.annotations.NullMarked;
