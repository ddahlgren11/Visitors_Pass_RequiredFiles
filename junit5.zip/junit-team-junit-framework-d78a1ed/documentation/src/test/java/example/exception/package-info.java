
@NullMarked
package example.exception;

import org.jspecify.annotations.NullMarked;
