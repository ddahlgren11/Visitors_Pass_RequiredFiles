
@NullMarked
package example.sharedresources;

import org.jspecify.annotations.NullMarked;
