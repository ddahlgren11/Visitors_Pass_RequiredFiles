
@NullMarked
package example.extensions;

import org.jspecify.annotations.NullMarked;
