
@NullMarked
package example.interceptor;

import org.jspecify.annotations.NullMarked;
