/**
 * Tools to generate reports based on {@link org.apiguardian.api.API} annotations.
 */

package org.junit.api.tools;
