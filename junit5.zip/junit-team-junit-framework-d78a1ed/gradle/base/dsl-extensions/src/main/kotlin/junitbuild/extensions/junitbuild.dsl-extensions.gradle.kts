// Just a dummy plugin to get the extensions on the classpath of downstream builds
