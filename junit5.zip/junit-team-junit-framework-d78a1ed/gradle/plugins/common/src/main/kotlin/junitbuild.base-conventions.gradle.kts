plugins {
	eclipse
	id("junitbuild.java-toolchain-conventions")
	id("junitbuild.spotless-conventions")
}
