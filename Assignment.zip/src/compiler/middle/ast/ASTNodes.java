package compiler.middle.ast;

// Placeholder file: node implementations have been split into separate public classes
// in this package (VarDeclNode.java, AssignmentNode.java, FunctionDeclNode.java,
// LiteralNode.java, IdentifierNode.java). This placeholder prevents accidental
// duplicate definitions from this file.

