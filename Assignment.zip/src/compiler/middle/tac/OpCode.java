package compiler.middle.tac;

public enum OpCode {
    LOAD_CONST,
    STORE_VAR,
    ADD,
    SUB,
    MUL,
    DIV
}