package compiler.frontend;

/**
 * Deprecated placeholder. Use the visitor interface under
 * `compiler.frontend.ast.ASTVisitor` instead.
 */
@Deprecated
public interface ASTVisitor<T> {
}
