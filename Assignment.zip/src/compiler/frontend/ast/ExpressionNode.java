package compiler.frontend.ast;

public abstract class ExpressionNode extends ASTNode {
}
