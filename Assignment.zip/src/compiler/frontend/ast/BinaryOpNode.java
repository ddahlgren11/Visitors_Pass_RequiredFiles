package compiler.frontend.ast;

// Legacy BinaryOpNode removed from this location. Use BinaryExprNode in this package or
// the original BinaryOpNode in compiler.frontend as appropriate.
