package compiler.frontend.ast;

public abstract class StatementNode extends ASTNode {
}
