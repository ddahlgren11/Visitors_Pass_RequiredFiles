package compiler.frontend.ast;

/**
 * Generic visitor interface for the frontend AST.
 * @param <T> visitor result type
 */
public interface ASTVisitor<T> {
    T visit(BinaryExprNode node);
    T visit(AssignmentNode node);
    T visit(VarDeclNode node);
    T visit(LiteralNode node);
    T visit(IdentifierNode node);
    T visit(BlockNode node);
    T visit(FunctionDeclNode node);
    T visit(ReturnNode node);
    T visit(IfNode node);
    T visit(ForNode node);
    T visit(WhileNode node);
}
