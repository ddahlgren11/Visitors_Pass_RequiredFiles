package compiler.frontend;

public class ParseException extends Exception {
    public ParseException() { super(); }
    public ParseException(String message) { super(message); }
}
