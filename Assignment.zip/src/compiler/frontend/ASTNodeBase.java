package compiler.frontend;

public abstract class ASTNodeBase {
    public abstract ASTTestTree toASTTestTree();
}