package compiler.frontend;


public class Main{}

