package compiler.frontend.visitor;

import compiler.frontend.ast.*;
import compiler.infra.Diagnostics;
import compiler.middle.SymbolTable;
import compiler.middle.Symbol;
import compiler.middle.Kind;

public class SymbolTableBuilderVisitor implements ASTVisitor {
    private final SymbolTable table;
    private final Diagnostics diag;

    public SymbolTableBuilderVisitor(SymbolTable table, Diagnostics diag) {
        this.table = table;
        this.diag = diag;
    }

    @Override
    public void visitAssignmentNode(AssignmentNode node) {
        node.getTarget().accept(this);
        node.getExpression().accept(this);
    }

    @Override
    public void visitBinaryExprNode(BinaryExprNode node) {
        node.getLeft().accept(this);
        node.getRight().accept(this);
    }

    @Override
    public void visitBinaryOpNode(BinaryOpNode node) {
        node.left.accept(this);
        node.right.accept(this);
    }

    @Override
    public void visitBlockNode(BlockNode node) {
        table.enterScope();
        for (ASTNode statement : node.getStatements()) {
            statement.accept(this);
        }
        table.exitScope();
    }

    @Override
    public void visitForNode(ForNode node) {
        table.enterScope();
        if (node.getInit() != null) {
            node.getInit().accept(this);
        }
        if (node.getCond() != null) {
            node.getCond().accept(this);
        }
        if (node.getUpdate() != null) {
            node.getUpdate().accept(this);
        }
        node.getBody().accept(this);
        table.exitScope();
    }

    @Override
    public void visitFunctionDeclNode(FunctionDeclNode node) {
        Symbol sym = new Symbol(node.getName(), Kind.FUNCTION, node);
        if (!table.declare(sym)) {
            diag.addError("Duplicate declaration: " + node.getName());
        }
        table.enterScope();
        for (VarDeclNode param : node.getParams()) {
             // Params are like variables in local scope
             Symbol paramSym = new Symbol(param.name, Kind.PARAMETER, param);
             if (!table.declare(paramSym)) {
                 diag.addError("Duplicate parameter: " + param.name);
             }
            // We do NOT call param.accept(this) because visitVarDeclNode would
            // try to declare it again as Kind.VARIABLE.
            // Although visitVarDeclNode uses Kind.VARIABLE, we want Kind.PARAMETER.
        }
        node.getBody().accept(this);
        table.exitScope();
    }

    @Override
    public void visitIdentifierNode(IdentifierNode node) {
        if (node.getName().equals("this")) return;
        if (!table.lookup(node.getName()).isPresent()) {
            diag.addError("Use of undeclared variable: " + node.getName());
        }
    }

    @Override
    public void visitIfNode(IfNode node) {
        node.getCond().accept(this);
        node.getThenBlock().accept(this);
        if (node.getElseBlock() != null) {
            node.getElseBlock().accept(this);
        }
    }

    @Override
    public void visitLiteralNode(LiteralNode node) {
        // Do nothing
    }

    @Override
    public void visitReturnNode(ReturnNode node) {
        if (node.getExpr() != null) {
            node.getExpr().accept(this);
        }
    }

    @Override
    public void visitVarDeclNode(VarDeclNode node) {
        Symbol sym = new Symbol(node.getName(), Kind.VARIABLE, node);
        if (!table.declare(sym)) {
            diag.addError("Duplicate declaration: " + node.getName());
        }
        if (node.getInitializer() != null) {
            node.getInitializer().accept(this);
        }
    }

    @Override
    public void visitWhileNode(WhileNode node) {
        node.getCond().accept(this);
        node.getBody().accept(this);
    }

    @Override
    public void visitUnaryOpNode(UnaryOpNode node) {
        node.expr.accept(this);
    }

    @Override
    public void visitEmptyNode(EmptyNode emptyNode) {
        // Do nothing
    }

    @Override
    public void visitClassDeclNode(ClassDeclNode node) {
        Symbol sym = new Symbol(node.className, Kind.TYPE, node);
        if (!table.declare(sym)) {
            diag.addError("Duplicate declaration: " + node.className);
        }
        table.enterScope();
        for (VarDeclNode field : node.fields) {
            field.accept(this);
        }
        for (FunctionDeclNode method : node.methods) {
            if (method.name.equals(node.className)) {
                // Constructor: visit body but do not declare in symbol table to avoid shadowing class
                table.enterScope();
                for (VarDeclNode param : method.getParams()) {
                    Symbol paramSym = new Symbol(param.name, Kind.PARAMETER, param);
                    if (!table.declare(paramSym)) {
                        diag.addError("Duplicate parameter: " + param.name);
                    }
                }
                method.getBody().accept(this);
                table.exitScope();
            } else {
                method.accept(this);
            }
        }
        table.exitScope();
    }

    @Override
    public void visitNewExprNode(NewExprNode node) {
        for (ASTNode arg : node.args) {
            arg.accept(this);
        }
    }

    @Override
    public void visitMethodCallNode(MethodCallNode node) {
        if (node.object != null) {
            node.object.accept(this);
        }
        for (ASTNode arg : node.args) {
            arg.accept(this);
        }
    }

    @Override
    public void visitMemberAccessNode(MemberAccessNode node) {
        node.object.accept(this);
    }
}