public class DiagnosticReporter {

}
