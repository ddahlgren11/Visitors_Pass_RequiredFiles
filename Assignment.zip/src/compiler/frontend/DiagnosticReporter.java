
public class DiagnosticReporter {

}
